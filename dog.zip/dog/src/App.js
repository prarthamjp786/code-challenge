import React from 'react';
import './App.css';
import { Component } from 'react';
import DogList from './component/DogList';

class App extends Component {
  constructor() {
    super();
    this.state = {
      dogs: [],
      images: [],

      searchDog: undefined
    }
  }

  searchDog = () => {
    fetch('https://dog.ceo/api/breeds/list/all')
      .then((response) => {
        return response.json();
      }).then((myJson, err) => {
        if (err) {
          console.log(err);
        }
        this.setState({
          dogs: Object.keys(myJson.message)
        })
        //console.log(this.state.dogs);
      });
  }

  searchImage = () => {
    fetch('https://dog.ceo/api/breeds/image/random/50')
      .then((response) => {
        return response.json();
      }).then((myJson, err) => {
        if (err) {
          console.log(err);
        }
        this.setState({
          images: myJson.message
        });
        console.log(this.state.images);
      });
  }

  componentDidMount() {
    this.searchDog();
    this.searchImage();
  }

  render() {
    return (
      <div className="App">
        <div className="container">
          <h1>List of All breeds</h1>
          {/* <img src={this.state.images} />
          {
            this.state.dogs.map((item, index) => {
              return (
                <DogList key={index} dogData={item} image={this.state.images} />
              );
            })
          } */}
          <div className="row">
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image captilize">
                  <img src={this.state.images[0]} />
                  <span class="card-title">{this.state.dogs[0]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[0]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[1]} />
                  <span class="card-title">{this.state.dogs[1]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[1]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[2]} />
                  <span class="card-title">{this.state.dogs[2]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[2]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[3]} />
                  <span class="card-title">{this.state.dogs[3]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[3]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[4]} />
                  <span class="card-title">{this.state.dogs[4]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[4]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[5]} />
                  <span class="card-title">{this.state.dogs[5]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[5]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[6]} />
                  <span class="card-title">{this.state.dogs[6]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[6]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[7]} />
                  <span class="card-title">{this.state.dogs[7]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[7]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card" style={{ width: 300 }}>
                <div className="card-image">
                  <img src={this.state.images[8]} />
                  <span class="card-title">{this.state.dogs[8]}</span>
                </div>
                <div className="card-content">
                  {this.state.dogs[8]}
                  <p>A random dog image that gets updated every time you refresh</p>
                </div>
                <div class="card-action">
                  <a href="#">Add</a>
                </div>
              </div>
            </div>
          </div>
          {/* {
            this.state.dogs.map((item, index) => {
              return (
                <div className="card" style={{ width: 300 }}>
                  <div className="card-image">
                    <img src={this.state.images} />
                  </div>
                  <div className="card-content">
                    {item}
                  </div>
                  <div class="card-action">
                    <a href="#">Add</a>
                  </div>
                </div>
              );
            })
          } */}
        </div>
      </div >
    );
  }
}

export default App;
