import React from 'react'

const DogList = props => {
    return (
        <div className="post card cardStyle" style={{ padding: 10, width: "80%", backgroundColor: "#ADEFD1FF" }}>
            <span className="card-title">{props.dogData}</span>
            <img src={props.imageData} />
        </div>
    )
}

export default DogList;